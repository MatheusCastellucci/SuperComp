#include <iostream>
#include <vector>
#include <algorithm>
#include <chrono>
#include <cstdlib>
#include <ctime>

bool subsetSum(const std::vector<int>& set, int targetSum) {
    int currentSum = 0;
    std::vector<int> sortedSet = set;
    std::sort(sortedSet.begin(), sortedSet.end(), std::greater<int>());

    for (const int& num : sortedSet) {
        if (currentSum + num <= targetSum) {
            currentSum += num;
        }
        if (currentSum == targetSum) {
            return true;
        }
    }
    return false;
}

void executeSubsetSumTest(int vectorSize, int targetSum) {
    std::vector<int> randomSet(vectorSize);

    for (int& value : randomSet) {
        value = rand() % 100 + 1; // Valores entre 1 e 100
    }

    auto startTime = std::chrono::high_resolution_clock::now();
    bool subconjunto = subsetSum(randomSet, targetSum);
    auto endTime = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> elapsedTime = endTime - startTime;

    if (subconjunto) {
        std::cout << "Resultado: Encontrou um subconjunto com soma igual a " << targetSum << std::endl;
    } else {
        std::cout << "Resultado: Nenhum subconjunto encontrado com soma " << targetSum << std::endl;
    }

    std::cout << "Tempo de execucao: " << elapsedTime.count() << " segundos" << std::endl;
}

int main() {
    srand(static_cast<unsigned int>(time(0)));

    int vectorSize, targetSum;
    std::cout << "Digite o tamanho do vetor: ";
    std::cin >> vectorSize;

    std::cout << "Digite a soma alvo: ";
    std::cin >> targetSum;

    executeSubsetSumTest(vectorSize, targetSum);
    return 0;
}
