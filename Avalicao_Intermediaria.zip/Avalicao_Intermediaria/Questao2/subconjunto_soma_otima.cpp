#include <iostream>
#include <vector>
#include <chrono>
#include <cstdlib>
#include <ctime>

bool subsetSumOptimal(const std::vector<int>& set, int n, int sum) {
    if (sum == 0) return true;
    if (n == 0 && sum != 0) return false;
    if (set[n-1] > sum) return subsetSumOptimal(set, n-1, sum);
    return subsetSumOptimal(set, n-1, sum) || subsetSumOptimal(set, n-1, sum - set[n-1]);
}

void executeOptimalTest(int n, int targetSum) {
    std::vector<int> set(n);
    for (int i = 0; i < n; ++i) {
        set[i] = rand() % 100 + 1; // Números aleatórios entre 1 e 100
    }

    std::cout << "Soma alvo: " << targetSum << std::endl;

    auto startTime  = std::chrono::high_resolution_clock::now();
    bool subconjunto = subsetSumOptimal(set, set.size(), targetSum);
    auto endTime  = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double> duration = endTime  - startTime ;

    if (subconjunto) {
        std::cout << "Resultado: Encontrou um subconjunto cuja soma eh igual a " << targetSum << std::endl;
    } else {
        std::cout << "Resultado: Nenhum subconjunto encontrado com a soma " << targetSum << std::endl;
    }

    std::cout << "Tempo de execucao: " << duration.count() << " segundos" << std::endl << std::endl;
}

int main() {
    srand(static_cast<unsigned int>(time(0)));
    int n, targetSum;
    std::cout << "Digite o tamanho do vetor (n): ";
    std::cin >> n;
    std::cout << "Digite a soma alvo: ";
    std::cin >> targetSum;
    executeOptimalTest(n, targetSum);
    return 0;
}