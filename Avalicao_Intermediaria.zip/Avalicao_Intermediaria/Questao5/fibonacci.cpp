#include <iostream>
#include <chrono>

long long int func_fibonacci(long long int n) {
    if (n <= 1) {
        return n;
    } else {
        return func_fibonacci(n - 1) + func_fibonacci(n - 2);
    }
}

int main() {
    long long int numero_fibo;
    std::cout << "Digite o valor de N para calcular Fibonacci: ";
    std::cin >> numero_fibo;

    auto start = std::chrono::high_resolution_clock::now();
    long long int result = func_fibonacci(numero_fibo);
    auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double, std::milli> duration = end - start;
    std::cout << "Fibonacci de " << numero_fibo << " eh " << result << std::endl;
    std::cout << "Tempo de execucao: " << duration.count() << " ms" << std::endl;
    return 0;
}
