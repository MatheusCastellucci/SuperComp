#include <iostream>
#include <vector>
#include <chrono>

long long int func_fibonacci(int n, std::vector<long long int>& memo) {
    if (n <= 1) {
        return n;
    }
    if (memo[n] != -1) {
        return memo[n];
    }
    memo[n] = func_fibonacci(n - 1, memo) + func_fibonacci(n - 2, memo);
    return memo[n];
}

int main() {
    int numero_fibo;
    std::cout << "Digite o valor de N para calcular Fibonacci: ";
    std::cin >> numero_fibo;
    std::vector<long long int> memo(numero_fibo + 1, -1);

    auto start = std::chrono::high_resolution_clock::now();
    long long int result = func_fibonacci(numero_fibo, memo);
    auto end = std::chrono::high_resolution_clock::now();

    std::chrono::duration<double, std::milli> duration = end - start;

    std::cout << "Fibonacci de " << numero_fibo << " eh " << result << std::endl;
    std::cout << "Tempo de execucao: " << duration.count() << " ms" << std::endl;
    return 0;
}
